const express = require("express");
const router = express.Router();
const { getAllProducts, createProduct, deleteProduct } = require("../controllers/productController");
const auth = require("../middleware/authMiddleware");

router.get("/", getAllProducts);
router.post("/", auth, createProduct);
router.delete("/:id", auth, deleteProduct);

module.exports = router;