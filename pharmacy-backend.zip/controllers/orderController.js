const Order = require("../models/Order");

const createOrder = async (req, res) => {
  const { products, totalPrice } = req.body;
  const order = await Order.create({
    userId: req.user.id,
    products,
    totalPrice
  });
  res.status(201).json(order);
};

const getUserOrders = async (req, res) => {
  const orders = await Order.find({ userId: req.user.id }).populate("products.productId");
  res.json(orders);
};

module.exports = { createOrder, getUserOrders };